public class Ejercicio_6 {
    //¿Qué contiene la tabla generada por el algoritmo siguiente?
    //
    //Algo QueHace
    //# ??
    //Constante TAMAÑO       : entero <- 3
    //Variable i, j, val: entero
    //Variable tab2d: entero[TAMAÑO][TAMAÑO]
    //Inicio
    // val <- 1
    // Para j <- 0 a TAMAÑO - 1
    //   Para i <- 0 a TAMAÑO - 1
    //     tab2d[j][i] <- val
    //     val <- val + 1
    //   FPara
    // FPara
    //Fin
    //
    //Considerando j como el eje x e i como eje y, esta tabla contiene
    //los valores de uno a nueve, completando en primer lugar la primera fila, luego la segunda y por último la tercera.

    //Modificar el algoritmo anterior para que la tabla tenga cuatro filas y cuatro columnas con los valores de uno a dieciséis, completando en primer lugar la primera columna, luego la segunda, posteriormente la tercera y por último la cuarta.

    //Constante TAMAÑO       : entero <- 4
    //Variable i, j, val: entero
    //Variable tab2d: entero[TAMAÑO][TAMAÑO]
    //Inicio
    //val <- 1
    //Para i <- 0 a TAMAÑO - 1
    //  Para j <- 0 a TAMAÑO - 1
    //    tab2d[j][i] <- val
    //    val <- val + 1
    //  FPara
    //FPara
    //Fin

    //Para que de los valores deseados en el apartado 2:

    //Constante TAMAÑO       : entero <- 4
    //Variable i, j, val: entero
    //Variable tab2d: entero[TAMAÑO][TAMAÑO]
    //Inicio
    // val <- 1
    // Para i <- 0 a TAMAÑO - 1
    //   val <- i
    //   Para j <- 0 a TAMAÑO - 1
    //     tab2d[j][i] <- val
    //     val <- val + 1
    //   FPara
    // FPara
    //Fin
}
